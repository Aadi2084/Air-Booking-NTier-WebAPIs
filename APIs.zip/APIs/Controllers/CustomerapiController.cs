﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SharedModels.Models;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Data;
using System.CodeDom;


namespace APIs.Controllers
{
        [Route("api/customer")]
        [ApiController]
    public class CustomerapiController : ControllerBase
    {
        private string _connection =
            "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Client;Integrated Security=True;Connect Timeout=30;Encrypt=False";

        [HttpPost]
        public IActionResult CreateCustomer(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid customer data.");
            }

            try
            {
                using (SqlConnection con = new SqlConnection(_connection))
                {
                    using (SqlCommand cmd = new SqlCommand("ADD_CUSTOMER", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Name", customer.Name);
                        cmd.Parameters.AddWithValue("@City", customer.City);
                        cmd.Parameters.AddWithValue("@Country", customer.Country);
                        cmd.Parameters.AddWithValue("@PostalCode", customer.PostalCode);
                        cmd.Parameters.AddWithValue("@Phone", customer.Phone);
                        cmd.Parameters.AddWithValue("@Email", customer.Email);
                        cmd.Parameters.AddWithValue("@Password", customer.Password);

                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok("Success");
                        }
                        else
                        {
                            return BadRequest("Failed to insert customer.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("get-customer")]
        public IActionResult GetCustomer(string email, string password)
        {
            using (SqlConnection con = new SqlConnection(_connection))
            {
                using (SqlCommand cmd = new SqlCommand("GET_CUSTOMER", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password);

                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Customer customer = new Customer
                            {
                                Id = (int)reader["Id"],
                                Name = reader["Name"].ToString(),
                                Email = reader["Email"].ToString(),
                                Phone = reader["Phone"].ToString(),
                                City = reader["City"].ToString(),
                                Country = reader["Country"].ToString(),
                                PostalCode = reader["PostalCode"].ToString()
                            };
                            return Ok(customer);
                        }
                    }
                }
            }
            return Unauthorized("Invalid email or password.");
        }

    }
}
