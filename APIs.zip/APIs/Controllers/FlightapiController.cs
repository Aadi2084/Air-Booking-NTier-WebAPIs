﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SharedModels.Models;
using SharedModels.Models.ViewModels;

namespace APIs.Controllers
{
    [Route("api/flight")]
    [ApiController]
    public class FlightapiController : Controller
    {
        private string _connection =
            "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Client;Integrated Security=True;Connect Timeout=30;Encrypt=False";

        [HttpGet]
        [Route("get-flight")]
        public IActionResult GetFlightResult(string source, string destination, DateTime flightDate)
        {
            using (SqlConnection con = new SqlConnection(_connection))
            {
                using(SqlCommand cmd= new SqlCommand("GET_AVAILABLE_FLIGHT", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Source", source);
                    cmd.Parameters.AddWithValue("@Destination", destination);
                    cmd.Parameters.AddWithValue("@FlightDate", flightDate);
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        var flights = new List<object>();
                        while (reader.Read())
                        {
                            flights.Add(new
                            {
                                FlightId = reader["FlightId"],
                                FlightName = reader["FlightName"],
                                Source = reader["Source"],
                                Destination = reader["Destination"],
                                ImageUrl = reader["ImageUrl"],
                                FlightScheduleId = reader["FlightScheduleId"],
                                FlightDate = reader["FlightDate"],
                                TakeoffTime = reader["TakeoffTime"],
                                LandingTime = reader["LandingTime"],
                                Price = reader["Price"],
                                SeatType = reader["SeatType"],
                                SeatAvailability = reader["SeatAvailability"],
                                FlightSeatAvailabilityId = reader["FlightSeatAvailabilityId"]
    });
                        }
                        return Ok(flights);
                    }
                }
            }
        }

        [HttpGet]
        [Route("details")]
        public IActionResult GetFlightById(int flightId, int flightScheduleId, string seatType)
        {
            using(SqlConnection con = new SqlConnection(_connection))
            {
                using (SqlCommand cmd = new SqlCommand("GET_FLIGHT_BY_ID", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FlightId", flightId);
                    cmd.Parameters.AddWithValue("@FlightScheduleId", flightScheduleId);
                    cmd.Parameters.AddWithValue("@SeatType", seatType);
                    con.Open();

                    using SqlDataReader reader = cmd.ExecuteReader();
                    if(reader.Read())
                    {
                        var flight = new FlightResultViewModel
                        {
                            FlightId = Convert.ToInt32(reader["FlightId"]),
                            FlightName = reader["FlightName"].ToString(),
                            Source = reader["Source"].ToString(),
                            Destination = reader["Destination"].ToString(),
                            ImageUrl = reader["ImageUrl"].ToString(),
                            FlightScheduleId = Convert.ToInt32(reader["FlightScheduleId"]),
                            FlightDate = reader.GetDateTime(reader.GetOrdinal("FlightDate")),
                            TakeoffTime = reader["TakeoffTime"].ToString(),
                            LandingTime = reader["LandingTime"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"]),
                            SeatType = reader["SeatType"].ToString(),
                            SeatAvailability = Convert.ToInt32(reader["SeatAvailability"]),
                            FlightSeatAvailabilityId = Convert.ToInt32(reader["FlightSeatAvailabilityId"])
                        };

                        return Ok(flight);
                    }
                    else
                    {
                        return NotFound("No flight found with the given parameters.");
                    }
                }
            }
        }

        [HttpPost]
        [Route("guest")]
        public IActionResult AddGuest(Guest guest)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest("Invalid guest data.");
            }
            try
            {
                using(SqlConnection con = new SqlConnection(_connection))
                {
                    using(SqlCommand cmd = new SqlCommand("ADD_GUEST", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@FirstName", guest.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", guest.LastName);
                        cmd.Parameters.AddWithValue("@Gender", guest.Gender);
                        cmd.Parameters.AddWithValue("@Age", guest.Age);
                        cmd.Parameters.AddWithValue("@Email", guest.Email);
                        cmd.Parameters.AddWithValue("@Phone", guest.Phone);
                        cmd.Parameters.Add("@FlightSeatAvailabilityId", SqlDbType.Int).Value = guest.FlightSeatAvailabilityId;
                        cmd.Parameters.Add("@Price", SqlDbType.Decimal).Value = guest.Price;

                        con.Open();
                        int rowsAffected = Convert.ToInt32(cmd.ExecuteScalar());
                        if (rowsAffected>0)
                        {
                            return Ok("Success");
                        }
                        else
                        {
                            return BadRequest("Failed to add guest.");
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        [Route("confirmation")]
        public IActionResult Confirmation(int guestId)
        {
            using (SqlConnection con = new SqlConnection(_connection))
            {
                using (SqlCommand cmd = new SqlCommand("GET_FINAL_BOOK_DETAILS", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@GuestId", guestId);

                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            var result = new
                            {
                                GuestId = reader["GuestId"],
                                FirstName = reader["FirstName"],
                                LastName = reader["LastName"],
                                Gender = reader["Gender"],
                                Age = reader["Age"],
                                Email = reader["Email"],
                                Phone = reader["Phone"],
                                FlightSeatAvailabilityId = reader["FlightSeatAvailabilityId"],
                                FlightScheduleId = reader["FlightScheduleId"],
                                FlightId = reader["FlightId"],
                                Source = reader["Source"],
                                Destination = reader["Destination"],
                                FlightName = reader["FlightName"],
                                Price = reader["Price"],
                                SeatTypeId = reader["SeatTypeId"],
                                SeatType = reader["SeatType"]
                            };
                            return Ok(result);
                        }
                    }
                }
            }

            return NotFound("Guest not found!");
        }
    }
}
