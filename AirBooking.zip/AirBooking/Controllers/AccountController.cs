﻿using Microsoft.AspNetCore.Mvc;
using SharedModels.Models;
using Repositories.Interfaces;

namespace AirBooking.Controllers
{
    /// <summary>
    /// Account Controller
    /// </summary>
    public class AccountController : Controller
    {
        #region Private
        
        private readonly IAccountRepository _accountRepository;

        /// <summary>
        /// Checking if the customer is already registered.
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        private async Task<IActionResult> ProcessLoginAsync(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Email and Password are required.";
                return View("Login");
            }

            var customer = await _accountRepository.LogInAsync(email, password);

            if (customer == null)
            {
                ViewBag.Error = "Invalid email or password.";
                return View("Login");
            }

            SetUserSession(customer);
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Registering the user.
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        private async Task<IActionResult> ProcessRegistrationAsync(Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return View("Register", customer);
            }

            bool isRegistered = await _accountRepository.RegisterAsync(customer);

            if (isRegistered)
            {
                return RedirectToAction("LogIn");
            }

            ViewBag.Error = "Failed to create customer.";
            return View("Register", customer);
        }

        /// <summary>
        /// Setting up the user session.
        /// </summary>
        /// <param name="customer"></param>
        private void SetUserSession(Customer customer)
        {
            HttpContext.Session.SetString("UserId", customer.Id.ToString());
            HttpContext.Session.SetString("UserName", customer.Name);
        }

        #endregion

        #region API Methods
        public AccountController(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }

        /// <summary>
        /// HttpGet request to show LogIn.cshtml and HttpPost to call ProcessLoginAsync and return result.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> LogIn(string email, string password)
        {
            var result = await ProcessLoginAsync(email, password);
            return result;
        }

        /// <summary>
        /// Log out function.
        /// </summary>
        /// <returns></returns>
        public IActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        /// <summary>
        /// HttpGet request to show SignUp.cshtml and HttpPost to call ProcessRegistrationAsync and return result .
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(Customer customer)
        {
            var result = await ProcessRegistrationAsync(customer);
            return result;
        }

        #endregion

    }
}
