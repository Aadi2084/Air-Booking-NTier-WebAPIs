﻿using Microsoft.AspNetCore.Mvc;
using Repositories.Interfaces;
using SharedModels.Models;

namespace AirBooking.Controllers
{
    public class BookingController : Controller
    {

        private readonly IFlightRepository _flightRepository;

        private async Task<IActionResult> ProcessGuestAsync(Guest guest)
        {
            if (!ModelState.IsValid)
            {
                return View("AddGuest", guest);
            }

            bool isAdded = await _flightRepository.AddGuestAsync(guest);
            if (isAdded)
            {
                ViewBag.IsGuestAdded = true;  // Indicate that guest was added
                return View(new Guest());  // Return empty model for new form
            }

            ViewBag.Error = "Failed to create guest.";
            return View("AddGuest", guest);

        }

        public BookingController(IFlightRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }
        public IActionResult AddGuest()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddGuest(Guest guest)
        {
            var result = await ProcessGuestAsync(guest);
            return result;
        }
    }
}
