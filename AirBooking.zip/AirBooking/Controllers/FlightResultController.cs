﻿using Microsoft.AspNetCore.Mvc;
using SharedModels.Models;
using Repositories.Interfaces;
using System.Security.Cryptography.X509Certificates;
using SharedModels.Models.ViewModels;
using YourNamespace.Models;

namespace AirBooking.Controllers
{
    /// <summary>
    /// FlightResult Controller
    /// </summary>
    public class FlightResultController : Controller
    {
        #region Private

        private readonly IFlightRepository _flightRepository;

        #endregion

        #region API Methods
        public FlightResultController(IFlightRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }
        /// <summary>
        /// Http Post request takes an object of the FlightSearchViewModel and returns a list of flights
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> FlightSearch(FlightSearchViewModel searchModel)
        {
            try
            {
                var flights = await _flightRepository.GetFlightResult(searchModel.Source, searchModel.Destination, searchModel.Date);
                searchModel.FlightResults = flights;
                TempData["LastSearchSource"] = searchModel.Source;
                TempData["LastSearchDestination"] = searchModel.Destination;
                TempData["LastSearchDate"] = searchModel.Date.ToString();
                return View(searchModel);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching flight results: {ex.Message}");
                return View(new List<FlightResultViewModel>());
            }
        }


        /// <summary>
        /// Http Post request takes an object of the FlightSearchViewModel and returns detail of a flight
        /// </summary>
        /// <param name="detailModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> FlightDetails(FlightSearchViewModel detailModel)
        {
            try
            {
                if (detailModel == null)
                {
                    return BadRequest("Invalid search parameters.");
                }

                FlightResultViewModel flightDetails = await _flightRepository.GetFlightById(
                    detailModel.FlightId,
                    detailModel.FlightScheduleId,
                    detailModel.SeatType
                );

                if (flightDetails == null)
                {
                    return NotFound("Flight details not found.");
                }

                return View(flightDetails);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching flight details: {ex.Message}");
                return StatusCode(500, "An error occurred while fetching flight details.");
            }
        }
        #endregion

    }
}
