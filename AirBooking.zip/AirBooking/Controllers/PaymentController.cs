﻿using Microsoft.AspNetCore.Mvc;
using Stripe.Checkout;

namespace AirBooking.Controllers
{
    public class PaymentController : Controller
    {
        public IActionResult OrderConfirmation(string session_id)
        {
            if (string.IsNullOrEmpty(session_id))
            {
                return View("Fail"); // Missing session ID
            }

            var service = new SessionService();
            Session session = service.Get(session_id);

            if (session.PaymentStatus == "paid")
            {
                return View("Success");
            }
            return View("Fail");
        }

        public IActionResult Success()
        {
            return View();
        }

        public IActionResult Fail()
        {
            return View();
        }

        public IActionResult CheckOut(decimal price)
        {
            var domain = "https://localhost:44393/";

            var gstAmount = price * 0.18m;  // 18% GST
            var totalAmount = price + gstAmount; // Final amount

            var options = new SessionCreateOptions
            {
                SuccessUrl = $"{domain}Payment/OrderConfirmation?session_id={{CHECKOUT_SESSION_ID}}",
                CancelUrl = $"{domain}Payment/Fail",
                Mode = "payment",
                Currency = "inr",  // INR currency
                LineItems = new List<SessionLineItemOptions>
                {
                    // Base Price (Flight Ticket)
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            Currency = "inr",
                            UnitAmount = (long)(price * 100), // Convert to paise
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = "Flight Ticket"
                            }
                        },
                        Quantity = 1
                    },
                    // GST (18%)
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            Currency = "inr",
                            UnitAmount = (long)(gstAmount * 100), // Convert to paise
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = "GST (18%)"
                            }
                        },
                        Quantity = 1
                    }
                }
            };

            var service = new SessionService();
            Session session = service.Create(options);

            return Redirect(session.Url); // Redirect user to Stripe Checkout
        }
    }
}
