using Repositories;
using Repositories.Implementations;
using Repositories.Interfaces;
using Stripe;
using SharedModels.Models;

namespace AirBooking
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
            });
            builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            // Register HttpClient
            //builder.Services.AddHttpClient<IAccountRepository, AccountRepository>(client =>
            //{
            //    client.BaseAddress = new Uri("https://localhost:7283/api/");
            //});

            // Register Repository
            builder.Services.AddScoped<IAccountRepository, AccountRepository>();
            builder.Services.AddScoped<IFlightRepository, FlightRepository>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseSession();
            app.UseAuthentication();

            StripeConfiguration.ApiKey = builder.Configuration.GetSection("Stripe:SecretKey").Get<string>();
            app.UseAuthorization();
            
            
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }

        //public class Startup
        //{
        //    private readonly IConfiguration _configuration;

        //    public Startup(IConfiguration configuration)
        //    {
        //        _configuration = configuration;
        //    }

        //    public void ConfigureServices(IServiceCollection services)
        //    {
        //        services.Configure<StripeSettings>(_configuration.GetSection("Stripe"));

        //        Stripe.StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];
        //    }
        //}


        //public void ConfigureServices(IServiceCollection services)
        //{
        //    services.AddControllersWithViews();
        //    services.AddSession();
        //}

        //public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        //{
        //    app.UseSession();
        //    app.UseRouting();
        //    app.UseAuthorization();
        //    app.UseEndpoints(endpoints =>
        //    {
        //        endpoints.MapControllerRoute(
        //            name: "default",
        //            pattern: "{controller=Account}/{action=Login}/{id?}");
        //    });
        //}

    }
}
