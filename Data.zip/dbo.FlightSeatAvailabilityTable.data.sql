﻿INSERT INTO [dbo].[FlightSeatAvailabilityTable] (FlightScheduleId, SeatTypeId, SeatAvailability)
VALUES 
-- Indigo (Flight 1)
(1002, 1, 120),  -- Economy
(1002, 2, 30),   -- Business

(1003, 1, 150),  -- Economy
(1003, 2, 40),   -- Business

-- Air India (Flight 3 & 4)
(1004, 1, 200),  -- Economy
(1004, 2, 50),   -- Business
(1004, 3, 20),   -- First Class

(1005, 1, 180),  -- Economy
(1005, 2, 60),   -- Business
(1005, 3, 25),   -- First Class

-- Emirates (Flight 5 & 6)
(1006, 1, 250),  -- Economy
(1006, 2, 80),   -- Business
(1006, 3, 40),   -- First Class

(1007, 1, 230),  -- Economy
(1007, 2, 70),   -- Business
(1007, 3, 30),   -- First Class

-- Qatar Airways (Flight 7 & 8)
(1008, 1, 220),  -- Economy
(1008, 2, 90),   -- Business
(1008, 3, 35),   -- First Class

(1009, 1, 210),  -- Economy
(1009, 2, 85),   -- Business
(1009, 3, 28),   -- First Class

-- Lufthansa (Flight 9 & 10)
(1010, 1, 190),  -- Economy
(1010, 2, 75),   -- Business
(1010, 3, 22),   -- First Class

(1011, 1, 170), -- Economy
(1011, 2, 65),  -- Business
(1011, 3, 18);  -- First Class
