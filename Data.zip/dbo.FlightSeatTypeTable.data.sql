﻿-- Air India 101 has Economy & Business
INSERT INTO FlightSeatTypeTable (FlightId, SeatTypeId) VALUES 
(1, 1), -- Economy
(1, 2); -- Business

-- Emirates 202 has all 3 seat types
INSERT INTO FlightSeatTypeTable (FlightId, SeatTypeId) VALUES 
(2, 1), -- Economy
(2, 2), -- Business
(2, 3); -- First Class
