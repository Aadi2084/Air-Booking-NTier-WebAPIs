﻿INSERT INTO [dbo].[FlightTable] (FlightName, Source, Destination, ImageUrl)
VALUES
('Indigo 6E 501', 'Mumbai', 'Delhi', 'https://vectorseek.com/wp-content/uploads/2021/01/IndiGo-Logo-Vector-2048x2048.jpg'),
('Indigo 6E 501', 'Delhi', 'Bangalore', 'https://vectorseek.com/wp-content/uploads/2021/01/IndiGo-Logo-Vector-2048x2048.jpg'),
('Air India AI 101', 'Delhi', 'London', 'https://th.bing.com/th/id/R.5f9be5876eda5d373d7f91a8faf5e659?rik=AMH8TOMKrK2Y6w&riu=http%3a%2f%2flofrev.net%2fwp-content%2fphotos%2f2017%2f03%2fair_india_logo_download.jpg&ehk=zFeqOgOta8nERxJ4botm2uV5IJp4BKKlHJic8HtkLMo%3d&risl=&pid=ImgRaw&r=0'),
('Air India AI 101', 'Mumbai', 'Dubai', 'https://th.bing.com/th/id/R.5f9be5876eda5d373d7f91a8faf5e659?rik=AMH8TOMKrK2Y6w&riu=http%3a%2f%2flofrev.net%2fwp-content%2fphotos%2f2017%2f03%2fair_india_logo_download.jpg&ehk=zFeqOgOta8nERxJ4botm2uV5IJp4BKKlHJic8HtkLMo%3d&risl=&pid=ImgRaw&r=0'),
('Emirates EK 507', 'Dubai', 'New York', 'https://th.bing.com/th/id/OIP.tXI8CTSfqq5-JLrtmDgEygHaGq?w=191&h=180&c=7&r=0&o=5&pid=1.7'),
('Emirates EK 507', 'Dubai', 'Singapore', 'https://th.bing.com/th/id/OIP.tXI8CTSfqq5-JLrtmDgEygHaGq?w=191&h=180&c=7&r=0&o=5&pid=1.7'),
('Qatar Airways QR 905', 'Doha', 'Sydney', 'https://steigerlegal.ch/wp-content/uploads/2018/07/qatar-airways_logo_003.jpg'),
('Qatar Airways QR 905', 'Doha', 'Paris', 'https://steigerlegal.ch/wp-content/uploads/2018/07/qatar-airways_logo_003.jpg'),
('Lufthansa LH 760', 'Frankfurt', 'Delhi', 'https://th.bing.com/th/id/OIP.hVQqTsktmW1FKREdIWH8BQHaHf?w=164&h=180&c=7&r=0&o=5&pid=1.7'),
('Lufthansa LH 760', 'Frankfurt', 'Mumbai', 'https://th.bing.com/th/id/OIP.hVQqTsktmW1FKREdIWH8BQHaHf?w=164&h=180&c=7&r=0&o=5&pid=1.7');
