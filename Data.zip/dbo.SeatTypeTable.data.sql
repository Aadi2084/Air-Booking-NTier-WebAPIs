﻿INSERT INTO [dbo].[SeatTypeTable] (SeatType)
VALUES 
('Economy'),
('Business'),
('First Class');
