﻿using System.Net.Http;
using System.Text;
using System.Text.Json;
using SharedModels.Models;
using Repositories.Interfaces;

namespace Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly HttpClient _httpClient;

        public AccountRepository()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://localhost:7283/api/")
            };

        }

        public async Task<Customer?> LogInAsync(string email, string password)
        {
            string requestUrl = $"customer/get-customer?email={Uri.EscapeDataString(email)}&password={Uri.EscapeDataString(password)}";
            HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);

            if (response.IsSuccessStatusCode)
            {
                string jsonResponse = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<Customer>(jsonResponse, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            }
            return null;
        }

        public async Task<bool> RegisterAsync(Customer customer)
        {
            string jsonCustomer = JsonSerializer.Serialize(customer);
            HttpContent content = new StringContent(jsonCustomer, Encoding.UTF8, "application/json");

            HttpResponseMessage response = await _httpClient.PostAsync("customer", content);

            return response.IsSuccessStatusCode;
        }
    }
}
