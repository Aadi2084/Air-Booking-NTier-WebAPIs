﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Repositories.Interfaces;
using SharedModels.Models;
using SharedModels.Models.ViewModels;

namespace Repositories.Implementations
{
    public class FlightRepository : IFlightRepository
    {
        private readonly HttpClient _httpClient;

        public FlightRepository()
        {
            _httpClient = new HttpClient()
            {
                BaseAddress = new Uri("https://localhost:7283/api/")
            };
        }

        public async Task<List<FlightResultViewModel>> GetFlightResult(string source, string destination, DateTime flightDate)
        {
            try
            {
                // Construct the request URL
                // formattedDate = flightDate.ToString("MM-dd-yyyy"); // Convert to MM-dd-yyyy
                // The above conversion to string is not needed.
                string requestUrl = $"flight/get-flight?source={source}&destination={destination}&flightDate={flightDate:MM-dd-yyyy}";


                // Send the GET request
                HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);
                Console.WriteLine(response);
                if (response.IsSuccessStatusCode)
                {
                    // Deserialize the response body
                    var flightResults = await response.Content.ReadFromJsonAsync<List<FlightResultViewModel>>();
                    Console.WriteLine(flightResults);
                    return flightResults ?? new List<FlightResultViewModel>();
                }
                else
                {
                    Console.WriteLine($"API call failed with status code: {response.StatusCode}");
                    return new List<FlightResultViewModel>(); // Return empty list on failure
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching flight data: {ex.Message}");
                return new List<FlightResultViewModel>(); // Return empty list if an exception occurs
            }
        }

        public async Task<FlightResultViewModel> GetFlightById(int flightId, int flightScheduleId, string seatType)
        {
            try
            {
                string requestUrl = $"flight/details?flightId={flightId}&flightScheduleId={flightScheduleId}&seatType={seatType}";
                HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);
                if (response.IsSuccessStatusCode)
                {
                    var flightData = await response.Content.ReadFromJsonAsync<FlightResultViewModel>();
                    return flightData ?? new FlightResultViewModel(); // Handle potential null response
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching flight datya: {ex.Message}");
                return new FlightResultViewModel();
            }
            return null;
        }

        public async Task<bool> AddGuestAsync(Guest guest)
        {
            string jsonGuest = JsonSerializer.Serialize(guest);
            HttpContent content = new StringContent(jsonGuest, Encoding.UTF8, "application/json");
        
            HttpResponseMessage response = await _httpClient.PostAsync("flight/guest", content);
            return response.IsSuccessStatusCode;
        }

        public async Task<BookDetailsViewModel> Confirmation(int guestId)
        {
            try
            {
                string requestUrl = $"flight/confirmation?guestId={guestId}";
                HttpResponseMessage response = await _httpClient.GetAsync(requestUrl);
                if(response.IsSuccessStatusCode)
                {
                    var details = await response.Content.ReadFromJsonAsync<BookDetailsViewModel>();
                    return details ?? new BookDetailsViewModel();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching flight datya: {ex.Message}");
                return new BookDetailsViewModel();
            }
            return null;
        }
    }
}
