﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedModels.Models;

namespace Repositories.Interfaces
{
    public interface IAccountRepository
    {
        Task<Customer?> LogInAsync(string email, string password);
        Task<bool> RegisterAsync(Customer customer);
    }
}
