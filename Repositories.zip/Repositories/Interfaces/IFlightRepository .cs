﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharedModels.Models;
using SharedModels.Models.ViewModels;

namespace Repositories.Interfaces
{
    public interface IFlightRepository
    {
        Task<List<FlightResultViewModel>> GetFlightResult(string source, string destination, DateTime flightDate);
        Task<FlightResultViewModel> GetFlightById(int flightId, int flightScheduleId, string seatType);
        //Task AddFlight(Flight flight);
        //Task DeleteFlight(int flightId);
        //Task UpdateFlight(Flight flight);
        Task<bool> AddGuestAsync (Guest guest);
        Task<BookDetailsViewModel> Confirmation(int guestId);

    }
}
