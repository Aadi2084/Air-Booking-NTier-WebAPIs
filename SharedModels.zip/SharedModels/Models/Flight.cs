﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SharedModels.Models
{
    public class Flight
    {
        [Key]
        public int FlightId { get; set; }

        [Required]
        [StringLength(100)]
        public string FlightName { get; set; }

        [Required]
        [StringLength(100)]
        public string Source { get; set; }

        [Required]
        [StringLength(100)]
        public string Destination { get; set; }

        public string ImageUrl { get; set; }

        // ✅ Add Virtual Collection for FlightSchedules
        public virtual ICollection<FlightSchedule> FlightSchedules { get; set; }
    }
}
