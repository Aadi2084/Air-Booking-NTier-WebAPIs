﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SharedModels.Models
{
    public class FlightSchedule
    {
        [Key]
        public int FlightScheduleId { get; set; }

        [ForeignKey("Flight")]
        public int FlightId { get; set; }

        [Required]
        public DateTime FlightDate { get; set; }

        [Required]
        public TimeSpan TakeoffTime { get; set; }

        [Required]
        public TimeSpan LandingTime { get; set; }

        [Required]
        public decimal Price { get; set; }

        // Navigation Properties
        public virtual Flight Flight { get; set; }
        public virtual ICollection<FlightSeatAvailability> FlightSeatAvailabilities { get; set; }
    }
}
