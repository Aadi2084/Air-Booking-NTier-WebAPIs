﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SharedModels.Models
{
    public class FlightSeatAvailability
    {
        [Key]
        public int FlightSeatAvailabilityId { get; set; }

        [ForeignKey("FlightSchedule")]
        public int FlightScheduleId { get; set; }

        [ForeignKey("SeatType")]
        public int SeatTypeId { get; set; }

        [Required]
        public int SeatAvailability { get; set; }

        // Navigation Properties
        public virtual FlightSchedule FlightSchedule { get; set; }
        public virtual SeatType SeatType { get; set; }
    }
}
