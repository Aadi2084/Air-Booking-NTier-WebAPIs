﻿using System.ComponentModel.DataAnnotations;

namespace SharedModels.Models
{
    public class SeatType
    {
        [Key]
        public int SeatTypeId { get; set; }

        [Required]
        [StringLength(50)]
        public string SeatTypeName { get; set; }
    }
}
