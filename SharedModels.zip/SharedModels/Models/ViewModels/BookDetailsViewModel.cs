﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedModels.Models.ViewModels
{
    public class BookDetailsViewModel
    {
        public int GuestId { get; set; }
     
        [StringLength(100)]
        public string FirstName { get; set; }

        [StringLength(100)]
        public string LastName { get; set; }

        public string Gender { get; set; }

        public int Age { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        [Phone]
        public string Phone { get; set; }

        public int FlightSeatAvailabilityId { get; set; }
        public int FlightScheduleId { get; set; }
        public int FlightId { get; set; }

        [StringLength(100)]
        public string FlightName { get; set; }

        [StringLength(100)]
        public string Source { get; set; }

        [StringLength(100)]
        public string Destination { get; set; }

        public decimal Price { get; set; }

        public int SeatTypeId { get; set; }

        [StringLength(50)]
        public string SeatTypeName { get; set; }
    }
}
