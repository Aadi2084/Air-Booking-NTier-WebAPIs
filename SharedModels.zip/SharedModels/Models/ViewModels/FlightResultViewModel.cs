﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedModels.Models.ViewModels
{
    public class FlightResultViewModel
    {
        public int FlightId { get; set; }
        public string FlightName { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public string ImageUrl { get; set; }

        public int FlightScheduleId { get; set; }
        public DateTime FlightDate { get; set; }
        //public TimeSpan TakeoffTime { get; set; }
        //public TimeSpan LandingTime { get; set; }
        public string TakeoffTime { get; set; } // Changed from TimeSpan to string
        public string LandingTime { get; set; } // Changed from TimeSpan to string
        public decimal Price { get; set; }
        // Single seat type per flight entry
        public string SeatType { get; set; }
        public int SeatAvailability { get; set; }
        public int FlightSeatAvailabilityId { get; set; }

        // public List<SeatAvailabilityViewModel> SeatAvailabilities { get; set; }
    }
    //public class SeatAvailabilityViewModel
    //{
    //    public string SeatTypeName { get; set; }
    //    public int AvailableSeats { get; set; }
    //}
}
