﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SharedModels.Models.ViewModels;

namespace YourNamespace.Models
{
    public class FlightSearchViewModel
    {
        public int FlightId { get; set; }
        public int FlightScheduleId { get; set; }
        public string SeatType { get; set; }
        public int FlightSeatAvailabilityId { get; set; }

        [Required]
        [Display(Name = "From")]
        public string Source { get; set; }

        [Required]
        [Display(Name = "To")]
        public string Destination { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date")]
        public DateTime Date { get; set; }

        public List<FlightResultViewModel> FlightResults { get; set; } = new List<FlightResultViewModel>();
    }
}
